﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Pacman_game
{
    public partial class Laberinto : Form
    {
        int tiempo=0;
        Pacman pacman;
        Audio audio= new Audio();
        List<ObjetoGrafico> Muros;
        List<ObjetoGrafico> Pastillas;
        List<ObjetoGrafico> Fantasmas= new List<ObjetoGrafico>();
       
        public Laberinto()
        {
            InitializeComponent();
        }

        private void Laberinto_Load(object sender, EventArgs e)
        {
            CargarPersonajes();
            CargarMuros();
            CargarPastillas();
            audio.Seleccionar(3);
            audio.Reproducir();
        }

        void CargarPersonajes()
        {
            pacman = new Pacman(60, 60);
            this.Controls.Add(pacman.Imagen);
            Fantasma fantasma1 = new Fantasma("pinky", 370, 230,1);
            this.Controls.Add(fantasma1.Imagen);
            Fantasmas.Add(fantasma1);
            Fantasma fantasma2 = new Fantasma("inky", 220, 200, 2);
            this.Controls.Add(fantasma2.Imagen);
            Fantasmas.Add(fantasma2);
            Fantasma fantasma3 = new Fantasma("blinky", 290, 200, 3);
            this.Controls.Add(fantasma3.Imagen);
            Fantasmas.Add(fantasma3);
            Fantasma fantasma4 = new Fantasma("clyde", 410, 250, 4);
            this.Controls.Add(fantasma4.Imagen);
            Fantasmas.Add(fantasma4);

        }

        void CargarMuros()
        {
            Muros = new List<ObjetoGrafico>();
            StreamReader reader = new StreamReader("coordenadas.txt");
            string linea;
            linea = reader.ReadLine();
            while(linea!=null)
            {
                string[] coor = linea.Split(';');
                Muro muro = new Muro(int.Parse(coor[0]), int.Parse(coor[1]));
                Muros.Add(muro);
                this.Controls.Add(muro.Imagen);
                linea = reader.ReadLine();
            }
            reader.Close();
        }

        void CargarPastillas()
        {
            Pastillas = new List<ObjetoGrafico>();
            StreamReader reader = new StreamReader("pastillas.txt");
            string linea;
            linea = reader.ReadLine();
            while (linea != null)
            {
                string[] coor = linea.Split(';');
                Pastilla pastilla = new Pastilla(int.Parse(coor[0]), int.Parse(coor[1]));
                Pastillas.Add(pastilla);
                this.Controls.Add(pastilla.Imagen);
                linea = reader.ReadLine();
            }
            reader.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pacman.AnimarPersonaje();
            foreach (Fantasma fan in Fantasmas)
            fan.AnimarPersonaje();
            int id = pacman.Comer(Pastillas);
            if(id>0)
            {
                this.Controls.Remove(Pastillas[id].Imagen);
                Pastillas.Remove(Pastillas[id]);
                lblPuntaje.Text = "Puntaje: " + pacman.Puntaje;
                audio.Seleccionar(1);
                audio.Reproducir();
            }
            id = pacman.PierdeUnVida(Fantasmas);
            if(id>0)
            {
                lblVidas.Text = "Vidas: " + pacman.Vidas;
                pacman.SetPos(60, 60);
                audio.Seleccionar(2);
                audio.Reproducir();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            tiempo++;
            if (tiempo < 10)
                lbltiempo.Text = "Tiempo : 0" + tiempo;
            else
                lbltiempo.Text = "Tiempo : " + tiempo;
            if(tiempo==10)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                MessageBox.Show("El tiempo terminó");
            }

        }

        private void Laberinto_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            letra = char.ToUpper(letra);
            if(letra=='W')
            {
                if (!pacman.EvaluarColision(Muros))
                    pacman.MoveUp();
                else
                    pacman.Robote(6);
            }
            else if(letra=='S')
            {
                if (!pacman.EvaluarColision(Muros))
                    pacman.MoveDown();
                else
                    pacman.Robote(6);
            }
            else if(letra=='A')
            {
                if (!pacman.EvaluarColision(Muros))
                    pacman.MoveLeft();
                else
                    pacman.Robote(6);
            }
            else if(letra=='D')
            {
                if (!pacman.EvaluarColision(Muros))
                    pacman.MoveRight();
               else
                    pacman.Robote(6);
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            foreach(Fantasma fan in Fantasmas)
            {
                fan.Mover(Muros, Fantasmas);
            }
        }
    }
}
