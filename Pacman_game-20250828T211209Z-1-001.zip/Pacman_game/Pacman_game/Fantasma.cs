﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman_game
{
    class Fantasma: Personaje
    {
        int dir;
        bool buscarDireccion = true;
        int id;
        public Fantasma()
        {

        }
        public Fantasma(string nombre, int x, int y , int id)
            :base(nombre,x,y,30,30)
        {
            this.id = id;
            
        }

        public void Mover(List<ObjetoGrafico>Muros, List<ObjetoGrafico>Fantasmas)
        {

            if(buscarDireccion)
            {
                var seed = Environment.TickCount;
                Random r1 = new Random(seed);
                for (int i=0; i<10;i++)
                {
                    dir = r1.Next(1,5);
                }
                buscarDireccion = false;
            }
            else
            {
                if(!this.EvaluarColision(Muros))
                {
                    switch(dir)
                    {
                        case 1:
                            this.MoveUp();
                            break;
                        case 2:
                            this.MoveDown();
                            break;
                        case 3:
                            this.MoveLeft();
                            break;
                        case 4:
                            this.MoveRight();
                            break;
                    }
                }
                else
                {
                    this.Robote(10);
                    buscarDireccion = true;
                }
                if (ColisionFantasma(Fantasmas))
                    buscarDireccion = true;
            }

        }

        bool ColisionFantasma(List<ObjetoGrafico>Fantasmas)
        {
            bool estado = false;
            foreach(Fantasma fan in Fantasmas)
            {
                if(this.id!=fan.id)
                {
                    if(this.EvaluarColision(fan))
                    {
                        this.Robote(10);
                        fan.Robote(10);
                        estado = true;
                    }
                }
            }
            return estado;
        }



    }
}
