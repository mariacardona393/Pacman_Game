﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman_game
{
    class Muro: ObjetoGrafico
    {

        public Muro(int x, int y):
            base("muro",x,y,18,18)
        {

        }
    }
}
