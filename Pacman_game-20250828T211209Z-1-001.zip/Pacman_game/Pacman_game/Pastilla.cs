﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman_game
{
    class Pastilla: ObjetoGrafico
    {
        public Pastilla()
        {

        }
        public Pastilla(int x, int y):base("pastilla",x,y,12,12)
        {

        }


    }
}
