﻿
namespace Pacman_game
{
    partial class Laberinto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.lblVidas = new System.Windows.Forms.Label();
            this.lbltiempo = new System.Windows.Forms.Label();
            this.lblPuntaje = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.timer10 = new System.Windows.Forms.Timer(this.components);
            this.timer11 = new System.Windows.Forms.Timer(this.components);
            this.timer12 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lblVidas
            // 
            this.lblVidas.AutoSize = true;
            this.lblVidas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblVidas.ForeColor = System.Drawing.Color.Red;
            this.lblVidas.Location = new System.Drawing.Point(128, 13);
            this.lblVidas.Name = "lblVidas";
            this.lblVidas.Size = new System.Drawing.Size(52, 21);
            this.lblVidas.TabIndex = 0;
            this.lblVidas.Text = "Vidas";
            // 
            // lbltiempo
            // 
            this.lbltiempo.AutoSize = true;
            this.lbltiempo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbltiempo.ForeColor = System.Drawing.Color.Red;
            this.lbltiempo.Location = new System.Drawing.Point(292, 13);
            this.lbltiempo.Name = "lbltiempo";
            this.lbltiempo.Size = new System.Drawing.Size(98, 21);
            this.lbltiempo.TabIndex = 1;
            this.lbltiempo.Text = "Tiempo : 00";
            // 
            // lblPuntaje
            // 
            this.lblPuntaje.AutoSize = true;
            this.lblPuntaje.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPuntaje.ForeColor = System.Drawing.Color.Red;
            this.lblPuntaje.Location = new System.Drawing.Point(458, 13);
            this.lblPuntaje.Name = "lblPuntaje";
            this.lblPuntaje.Size = new System.Drawing.Size(90, 21);
            this.lblPuntaje.TabIndex = 2;
            this.lblPuntaje.Text = "Puntaje : 0";
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            // 
            // timer4
            // 
            this.timer4.Interval = 1000;
            // 
            // timer5
            // 
            this.timer5.Interval = 1000;
            // 
            // timer6
            // 
            this.timer6.Enabled = true;
            this.timer6.Interval = 90;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // timer7
            // 
            this.timer7.Interval = 1000;
            // 
            // timer8
            // 
            this.timer8.Interval = 1000;
            // 
            // timer9
            // 
            this.timer9.Interval = 1000;
            // 
            // timer10
            // 
            this.timer10.Interval = 1000;
            // 
            // timer11
            // 
            this.timer11.Interval = 1000;
            // 
            // timer12
            // 
            this.timer12.Interval = 1000;
            // 
            // Laberinto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.lblPuntaje);
            this.Controls.Add(this.lbltiempo);
            this.Controls.Add(this.lblVidas);
            this.Name = "Laberinto";
            this.Text = "Pacman";
            this.Load += new System.EventHandler(this.Laberinto_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Laberinto_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lblVidas;
        private System.Windows.Forms.Label lbltiempo;
        private System.Windows.Forms.Label lblPuntaje;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Timer timer10;
        private System.Windows.Forms.Timer timer11;
        private System.Windows.Forms.Timer timer12;
    }
}