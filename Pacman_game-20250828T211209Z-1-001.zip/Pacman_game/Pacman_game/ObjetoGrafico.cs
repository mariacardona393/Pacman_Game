﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Pacman_game
{
    class ObjetoGrafico
    {
        //Atributos
        protected PictureBox imagen;
        protected int posx;
        protected int posy;
        protected string nombreRecurso;
        protected string nombre;

        public PictureBox Imagen { get => imagen; set => imagen = value; }
        public int Posx { get => posx; set => posx = value; }
        public int Posy { get => posy; set => posy = value; }

        public ObjetoGrafico()
        {
        }

        public ObjetoGrafico(string nombre,int x, int y, int w, int h)
        {
            this.nombre = nombre;
            this.nombreRecurso = nombre;
            imagen =new  PictureBox();
            imagen.Location = new Point(x, y);
            imagen.Size = new Size(w, h);
            imagen.BackColor = Color.Transparent;
            imagen.SizeMode = PictureBoxSizeMode.StretchImage;
            imagen.Image = 
                (Image)Properties.Resources.ResourceManager.GetObject(nombreRecurso);
            SetPos(x, y);
        }


       public void SetPos(int x, int y)
        {
            this.posx = x;
            this.posy = y;
            imagen.Location = new Point(posx, posy);
        }

        public virtual Rectangle GetBounds()
        {
            return imagen.Bounds;
        }
    }
}
