﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacman_game
{
    class Pacman: Personaje
    {
        int vidas;
        int puntaje;

        public Pacman()
        {
            vidas = 3;
        }
        public Pacman(int x, int y): base("pacman",x,y,30,30)
        {
            vidas = 3;
        }

        public int Vidas { get => vidas; }
        public int Puntaje { get => puntaje; }

        public int Comer(List<ObjetoGrafico>Pastillas)
        {
            int id = -1;
            for(int i=0; i<Pastillas.Count;i++)
            {
                if(this.EvaluarColision(Pastillas[i]))
                {
                    id = i;
                    puntaje++;
                }
            }
            return id;
        }
        public int PierdeUnVida(List<ObjetoGrafico> Fantasmas)
        {
            int id = -1;
            for (int i = 0; i < Fantasmas.Count; i++)
            {
                if (this.EvaluarColision(Fantasmas[i]))
                {
                    id = i;
                    if (vidas > 0)
                        vidas--;
                }
            }
            return id;
        }
    }
}
