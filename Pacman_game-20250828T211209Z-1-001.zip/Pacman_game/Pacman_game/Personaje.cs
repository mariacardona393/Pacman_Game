﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Pacman_game
{
    class Personaje: ObjetoGrafico
    {
        //Atributos
        int velocidad;
        string direccion;
        int estado;

        public Personaje()
        {
            velocidad = 3;
            direccion = "left";
            estado = 1;
        }
        public Personaje(string nombre, int x,int y, int w, int h)
            :base(nombre,x,y,w,h)
        {
            velocidad = 3;
            direccion = "left";
            estado = 1;
        }
        public void AnimarPersonaje()
        {
            switch(estado)
            {
                case 1:
                    nombreRecurso = nombre + '_' + estado + '_' + direccion;
                    estado = 2;
                    imagen.Image = 
                        (Image)Properties.Resources.ResourceManager.GetObject(nombreRecurso);
                    break;
                case 2:
                    nombreRecurso = nombre + '_' + estado + '_' + direccion;
                    estado = 1;
                    imagen.Image =
                        (Image)Properties.Resources.ResourceManager.GetObject(nombreRecurso);
                    break;
                default:
                    break;
            }
        }

        public void MoveUp()
        {
            posy -= velocidad;
            SetPos(posx, posy);
            direccion = "up";
        }
        public void MoveDown()
        {
            posy += velocidad;
            SetPos(posx, posy);
            direccion = "down";
        }
        public void MoveLeft()
        {
            posx -= velocidad;
            SetPos(posx, posy);
            direccion = "left";
        }
        public void MoveRight()
        {
            posx += velocidad;
            SetPos(posx, posy);
            direccion = "right";
          
        }

        public void Robote(int vel)
        {
            switch(direccion)
            {
                case "up":
                    {
                        this.posy += vel;
                        direccion = "down";
                    }
                    break;
                case "down":
                    {
                        this.posy -= vel;
                        direccion = "up";
                    }
                    break;
                case "left":
                    {
                        this.posx += vel;
                        direccion = "right";
                    }
                    break;
                case "right":
                    {
                        this.posx -= vel;
                        direccion = "left";
                    }
                    break;
                default:
                    break;
            }
            SetPos(posx, posy);
        }


        public bool EvaluarColision(List<ObjetoGrafico> objetos)
        {
            for (int i = 0; i < objetos.Count; i++)
            {
                if (this.GetBounds().IntersectsWith(objetos[i].GetBounds()))
                    return true;
            }
            return false;
        }

        public bool EvaluarColision(ObjetoGrafico objeto)
        {
                if (this.GetBounds().IntersectsWith(objeto.GetBounds()))
                    return true;
          
            return false;
        }
    }
}
